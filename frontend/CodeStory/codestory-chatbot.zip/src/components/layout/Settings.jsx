import React, { useState } from 'react';
import { FaUserEdit, FaPalette, FaSmile, FaInfoCircle, FaCheck } from 'react-icons/fa';
import './Settings.css';

const Settings = ({ user, onNicknameChange }) => {
    const [nickname, setNickname] = useState(user?.nickname || '');
    const [themeColor, setThemeColor] = useState('purple'); 
    const [emojiSet, setEmojiSet] = useState('3d'); 

    const handleSaveProfile = () => {
        alert(`닉네임이 '${nickname}'(으)로 변경되었습니다!`);
        if (onNicknameChange) onNicknameChange(nickname);
    };

    return (
        <div className="settings-container animate-fade-in">
            <h2 className="settings-title">설정</h2>
            <p className="settings-subtitle">나만의 다이어리를 꾸며보세요.</p>

            <div className="settings-section">
                <div className="section-header">
                    <FaUserEdit className="icon" />
                    <h3>프로필 설정</h3>
                </div>
                <div className="input-group">
                    <label>닉네임</label>
                    <div style={{display:'flex', gap:'8px'}}>
                        <input 
                            type="text" 
                            value={nickname} 
                            onChange={(e) => setNickname(e.target.value)}
                            placeholder="변경할 닉네임을 입력하세요"
                        />
                        <button className="save-btn" onClick={handleSaveProfile}>변경</button>
                    </div>
                </div>
            </div>

            <div className="settings-section">
                <div className="section-header">
                    <FaPalette className="icon" />
                    <h3>테마 색상</h3>
                </div>
                <div className="theme-options">
                    {['#6C5CE7', '#0984E3', '#E84393', '#00B894'].map((color) => (
                        <div 
                            key={color} 
                            className="color-circle" 
                            style={{ backgroundColor: color, border: themeColor === color ? '3px solid #333' : 'none' }}
                            onClick={() => alert('테마 변경 기능은 준비 중이에요! 🎨')}
                        >
                            {themeColor === color && <FaCheck color="white" />}
                        </div>
                    ))}
                </div>
            </div>

            <div className="settings-section">
                <div className="section-header">
                    <FaSmile className="icon" />
                    <h3>이모지 스타일</h3>
                </div>
                <div className="radio-group">
                    <label className={`radio-card ${emojiSet === '3d' ? 'active' : ''}`} onClick={() => setEmojiSet('3d')}>
                        <span className="emoji-preview">🥰</span>
                        <span>3D (기본)</span>
                    </label>
                    <label className={`radio-card ${emojiSet === 'flat' ? 'active' : ''}`} onClick={() => setEmojiSet('flat')}>
                        <span className="emoji-preview">🙂</span>
                        <span>심플 플랫</span>
                    </label>
                </div>
            </div>

            <div className="settings-section info-section">
                <div className="section-header">
                    <FaInfoCircle className="icon" />
                    <h3>앱 정보</h3>
                </div>
                <div className="info-row">
                    <span>현재 버전</span>
                    <span className="version-badge">v1.0.2 (Beta)</span>
                </div>
                <div className="info-row">
                    <span>개발자</span>
                    <span>CodeStory</span>
                </div>
                <div className="info-row">
                    <span>문의하기</span>
                    <span style={{textDecoration:'underline', cursor:'pointer'}}>help@codestory.com</span>
                </div>
            </div>
        </div>
    );
};

export default Settings;