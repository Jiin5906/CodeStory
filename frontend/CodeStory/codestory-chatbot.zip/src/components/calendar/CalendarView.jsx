import React from 'react';
import { 
    format, eachDayOfInterval, startOfYear, endOfYear, 
    getDay 
} from 'date-fns';
import { FaFire, FaTrophy, FaCalendarCheck } from 'react-icons/fa6';
import './CalendarView.css';

const CalendarView = ({ user, diaries }) => {
    const today = new Date();
    const yearStart = startOfYear(today);
    const yearEnd = endOfYear(today);
    
    const safeDiaries = Array.isArray(diaries) ? diaries : [];
    const allDays = eachDayOfInterval({ start: yearStart, end: yearEnd });

    const weeks = [];
    let currentWeek = [];
    const startDay = getDay(yearStart);
    for (let i = 0; i < startDay; i++) currentWeek.push(null);

    allDays.forEach((day) => {
        currentWeek.push(day);
        if (currentWeek.length === 7) {
            weeks.push(currentWeek);
            currentWeek = [];
        }
    });
    if (currentWeek.length > 0) {
        while (currentWeek.length < 7) currentWeek.push(null);
        weeks.push(currentWeek);
    }

    // [수정 1] 툴팁 내용 간소화 (날짜 + 이모지/상태만 표시)
    const getColorAndTooltip = (date) => {
        if (!date) return { color: 'transparent', tooltip: '' };
        const dateStr = format(date, 'yyyy-MM-dd');
        const diary = safeDiaries.find(d => d.date === dateStr);
        const dateLabel = format(date, 'M월 d일');

        if (!diary) return { color: '#EBEDF0', tooltip: `${dateLabel}: 기록 없음` };

        let color = '#69DB7C';
        const emoji = diary.emoji || '';
        if (emoji.match(/🥰|😊|행복/)) color = '#FFD43B';
        else if (emoji.match(/🔥|열정/)) color = '#FF6B6B';
        else if (emoji.match(/😢|😭|우울/)) color = '#748FFC';
        else if (emoji.match(/😫|피곤/)) color = '#ADB5BD';

        // 내용 미리보기 제거하고 간단하게 표시
        return { color, tooltip: `${dateLabel}: ${diary.emoji || '기록됨'}` };
    };

    const totalDiaries = safeDiaries.filter(d => d.date.startsWith(format(today, 'yyyy'))).length;
    
    return (
        <div className="calendar-view-container animate-fade-in">
            <div className="heatmap-header">
                <h2>{format(today, 'yyyy')}년의 감정 지도</h2>
                <p style={{color:'#888'}}>하루하루 쌓인 당신의 감정들을 색깔로 확인해보세요.</p>
            </div>
            
            {/* 통계 카드 (생략 - 기존과 동일) */}
            <div className="stats-cards">
                 {/* ... 기존 코드 유지 ... */}
                 <div className="stat-card"><div className="stat-icon"><FaTrophy /></div><div><div style={{fontSize:'24px', fontWeight:'bold'}}>{totalDiaries}개</div><div style={{fontSize:'13px', color:'#888'}}>올해 작성한 일기</div></div></div>
                 <div className="stat-card"><div className="stat-icon" style={{color:'#FF6B6B', background:'#FFF5F5'}}><FaFire /></div><div><div style={{fontSize:'24px', fontWeight:'bold'}}>진행 중</div><div style={{fontSize:'13px', color:'#888'}}>현재 연속 기록</div></div></div>
                 <div className="stat-card"><div className="stat-icon" style={{color:'#20C997', background:'#E6FCF5'}}><FaCalendarCheck /></div><div><div style={{fontSize:'24px', fontWeight:'bold'}}>{Math.round((totalDiaries/365)*100)}%</div><div style={{fontSize:'13px', color:'#888'}}>올해 기록 달성률</div></div></div>
            </div>

            <div className="heatmap-scroll-area">
                <div style={{display:'flex'}}>
                    <div className="day-labels">
                        <div className="day-label-text">일</div><div className="day-label-text">월</div><div className="day-label-text">화</div><div className="day-label-text">수</div><div className="day-label-text">목</div><div className="day-label-text">금</div><div className="day-label-text">토</div>
                    </div>

                    <div className="year-grid">
                        {weeks.map((week, wIdx) => {
                            // [수정 2] 첫 주와 마지막 주 확인
                            const isFirstWeek = wIdx === 0;
                            const isLastWeek = wIdx === weeks.length - 1;
                            
                            // 좌우 정렬 클래스 결정
                            let alignClass = 'tooltip-align-center'; // 기본 가운데 정렬
                            if (isFirstWeek) alignClass = 'tooltip-align-right'; // 첫 주는 오른쪽으로
                            else if (isLastWeek) alignClass = 'tooltip-align-left'; // 마지막 주는 왼쪽으로

                            return (
                                <div key={wIdx} className="week-col">
                                    {week.map((day, dIdx) => {
                                        const { color, tooltip } = getColorAndTooltip(day);
                                        // 상하 정렬 클래스 결정 (기존 유지)
                                        const verticalClass = dIdx < 2 ? 'tooltip-down' : 'tooltip-up';
                                        
                                        // 모든 클래스 조합
                                        const finalClasses = `day-cell ${verticalClass} ${alignClass}`;

                                        return (
                                            <div 
                                                key={dIdx} 
                                                className={finalClasses}
                                                style={{ backgroundColor: color }}
                                                data-tooltip={tooltip}
                                            ></div>
                                        );
                                    })}
                                </div>
                            );
                        })}
                    </div>
                </div>
            </div>
            {/* 범례 (생략 - 기존과 동일) */}
             <div className="legend">
                {/* ... 기존 코드 유지 ... */}
                <span>Less</span>
                <div className="legend-item"><div className="legend-color" style={{background:'#EBEDF0'}}></div> 없음</div>
                <div className="legend-item"><div className="legend-color" style={{background:'#ADB5BD'}}></div> 피곤</div>
                <div className="legend-item"><div className="legend-color" style={{background:'#748FFC'}}></div> 우울</div>
                <div className="legend-item"><div className="legend-color" style={{background:'#69DB7C'}}></div> 보통</div>
                <div className="legend-item"><div className="legend-color" style={{background:'#FFD43B'}}></div> 행복</div>
                <div className="legend-item"><div className="legend-color" style={{background:'#FF6B6B'}}></div> 열정</div>
                <span>More</span>
            </div>
        </div>
    );
};

export default CalendarView;