import { useState, useEffect } from 'react';
import { 
    format, startOfWeek, addDays, isSameDay, 
    startOfMonth, addMonths, subMonths,
    addWeeks, subWeeks, isAfter, startOfDay, isBefore
} from 'date-fns';
import { ko } from 'date-fns/locale';
import { 
    FaChevronRight, FaChevronLeft, FaQuoteLeft, 
    FaSignInAlt, FaSignOutAlt 
} from 'react-icons/fa';
import './MainDashboard.css';

const MainDashboard = ({ user, diaries, selectedDate, onDateChange, onLogout, onLoginRedirect }) => {
    
    // [중요] 서버 주소 상수 (포트가 다르다면 수정 필요)
    const BASE_URL = 'http://localhost:8080';

    const [weekDates, setWeekDates] = useState([]);
    const [isCalendarOpen, setIsCalendarOpen] = useState(false);

    const safeDiaries = Array.isArray(diaries) ? diaries : [];
    const selectedDateStr = format(selectedDate, 'yyyy-MM-dd');
    const currentDiary = safeDiaries.find(d => d.date === selectedDateStr);
    const isGuest = user?.id === 0;

    const today = startOfDay(new Date());

    useEffect(() => {
        const start = startOfWeek(selectedDate, { weekStartsOn: 0 });
        const days = [];
        for (let i = 0; i < 7; i++) {
            days.push(addDays(start, i));
        }
        setWeekDates(days);
    }, [selectedDate]);

    const startOfCurrentViewWeek = startOfWeek(selectedDate, { weekStartsOn: 0 });
    const startOfRealThisWeek = startOfWeek(today, { weekStartsOn: 0 });
    const isNextWeekDisabled = !isBefore(startOfCurrentViewWeek, startOfRealThisWeek);

    const handlePrevWeek = () => { onDateChange(subWeeks(selectedDate, 1)); };
    const handleNextWeek = () => { if (!isNextWeekDisabled) onDateChange(addWeeks(selectedDate, 1)); };

    const generateMonthCalendar = () => {
        const monthStart = startOfMonth(selectedDate);
        const startDate = startOfWeek(monthStart, { weekStartsOn: 0 });
        const calendar = [];
        let day = startDate;
        for (let i = 0; i < 42; i++) {
            calendar.push(day);
            day = addDays(day, 1);
        }
        return calendar;
    };
    const monthDays = isCalendarOpen ? generateMonthCalendar() : [];
    const dayLabels = ['일', '월', '화', '수', '목', '금', '토'];

    return (
        <div className="main-content">
            <div className="main-header flex justify-between items-center px-2 pt-6 pb-4">
                <div className="flex items-center gap-2 cursor-pointer hover:bg-gray-100 px-3 py-2 rounded-xl transition-colors group" onClick={() => setIsCalendarOpen(true)}>
                    <span className="text-2xl font-extrabold text-gray-900 tracking-tight group-hover:text-[#6C5CE7] transition-colors">{format(selectedDate, 'yyyy.MM')}</span>
                    <FaChevronRight className={`text-xs text-gray-300 group-hover:text-[#6C5CE7] transition-transform ${isCalendarOpen ? 'rotate-90' : ''}`} />
                </div>
                <div>
                    {isGuest ? (
                        <button onClick={onLoginRedirect} className="flex items-center gap-1 text-sm font-bold text-[#6C5CE7] hover:bg-[#F0F0FF] px-4 py-2 rounded-full transition-colors"><span>로그인</span><FaSignInAlt /></button>
                    ) : (
                        <button onClick={onLogout} className="flex items-center gap-2 text-sm text-gray-400 hover:text-red-500 hover:bg-red-50 px-3 py-2 rounded-full transition-colors">
                            <span className="text-xs font-medium text-gray-500">{user?.nickname}님</span><FaSignOutAlt />
                        </button>
                    )}
                </div>
            </div>

            <div className="flex items-center justify-between mb-6">
                <button onClick={handlePrevWeek} className="p-3 text-gray-400 hover:text-[#6C5CE7] hover:bg-gray-100 rounded-full transition-colors flex-shrink-0"><FaChevronLeft size={16} /></button>
                <div className="flex-1 mx-2">
                    <div className="flex justify-around text-center mb-2">
                        {dayLabels.map((day, i) => (<div key={i} className={`text-xs font-bold w-[14%] ${i === 0 ? 'text-red-400' : 'text-gray-400'}`}>{day}</div>))}
                    </div>
                    <div className="flex justify-around text-center">
                        {weekDates.map((date, i) => {
                            const dateStr = format(date, 'yyyy-MM-dd');
                            const isSelected = isSameDay(date, selectedDate);
                            const diaryForDay = safeDiaries.find(d => d.date === dateStr);
                            const isFuture = isAfter(date, today);
                            return (
                                <div key={i} className={`date-item flex flex-col items-center pt-3 rounded-2xl relative transition-all w-[14%] h-[4.5rem] ${isSelected ? 'bg-[#6C5CE7] shadow-lg shadow-indigo-200 transform -translate-y-1' : ''} ${isFuture ? 'opacity-30 cursor-not-allowed' : 'cursor-pointer hover:bg-gray-50'}`} onClick={() => { if (!isFuture) onDateChange(date); }}>
                                    <span className={`text-base font-bold mb-1 ${isSelected ? 'text-white' : (i === 0 ? 'text-red-400' : 'text-gray-600')}`}>{format(date, 'd')}</span>
                                    {diaryForDay && diaryForDay.emoji && (<span className="absolute bottom-2 text-sm animate-bounce">{diaryForDay.emoji}</span>)}
                                </div>
                            );
                        })}
                    </div>
                </div>
                <button onClick={handleNextWeek} disabled={isNextWeekDisabled} className={`p-3 rounded-full transition-colors flex-shrink-0 ${isNextWeekDisabled ? 'text-gray-200 cursor-not-allowed' : 'text-gray-400 hover:text-[#6C5CE7] hover:bg-gray-100 cursor-pointer'}`}><FaChevronRight size={16} /></button>
            </div>

            <div className="flex-1 px-2 pb-24 overflow-y-auto scrollbar-hide">
                <div className="text-center text-sm font-bold text-gray-500 mb-6">{format(selectedDate, 'M월 d일 EEEE', { locale: ko })}</div>

                {currentDiary ? (
                    <div className="diary-entry flex-col !gap-5 bg-white p-6 rounded-[24px] shadow-sm border border-gray-100 animate-fade-in">
                        <div className="flex justify-between items-center pb-4 border-b border-gray-50">
                            <div>
                                <h2 className="text-lg font-bold text-gray-900 mb-2">{user?.nickname}님의 하루</h2>
                                <div className="flex gap-2">
                                    {currentDiary.tags?.map((tag, idx) => (
                                        <span key={idx} className="text-[11px] text-[#6C5CE7] bg-[#F0F0FF] px-3 py-1 rounded-full font-bold">#{tag}</span>
                                    ))}
                                </div>
                            </div>
                            <div className="text-5xl drop-shadow-sm">{currentDiary.emoji}</div>
                        </div>

                        {/* [추가됨] 사진이 있으면 보여주는 부분 */}
                        {currentDiary.imageUrl && (
                            <div className="mb-4 rounded-xl overflow-hidden border border-gray-100 shadow-sm">
                                <img 
                                    src={`${BASE_URL}${currentDiary.imageUrl}`} 
                                    alt="오늘의 사진" 
                                    className="w-full h-auto object-cover max-h-[300px]"
                                    onError={(e) => { e.target.style.display = 'none'; }} // 이미지 로드 실패 시 숨김
                                />
                            </div>
                        )}
                        
                        <p className="text-gray-700 leading-8 text-[16px] whitespace-pre-wrap font-medium">{currentDiary.content}</p>

                        <div className="ai-box mt-4 bg-[#F8F9FA] p-5 rounded-2xl border-l-4 border-[#6C5CE7]">
                            <div style={{display:'flex', alignItems:'center', gap:'8px', marginBottom:'6px'}}>
                                <FaQuoteLeft className="text-[#6C5CE7]" />
                                <span style={{fontSize:'12px', fontWeight:'bold', color:'#6C5CE7'}}>CodeStory의 공감</span>
                            </div>
                            <p className="ai-msg text-sm text-gray-600 leading-relaxed">{currentDiary.aiResponse}</p>
                        </div>
                    </div>
                ) : (
                    <div className="text-center pt-10">
                        <div className="text-6xl mb-6 opacity-10 grayscale">📝</div>
                        <p className="text-gray-500 font-bold text-lg">작성된 일기가 없어요</p>
                        {isAfter(selectedDate, today) ? (
                            <p className="text-sm text-red-400 mt-2 font-medium bg-red-50 inline-block px-3 py-1 rounded-full">미래의 일기는 아직 쓸 수 없어요 🤫</p>
                        ) : (
                            <p className="text-sm text-gray-400 mt-2">오늘의 이야기를 들려주세요.</p>
                        )}
                    </div>
                )}
            </div>
            
            {/* 전체 달력 팝업 (기존 코드 유지) */}
            {isCalendarOpen && (
                <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm p-4 text-gray-800" onClick={() => setIsCalendarOpen(false)}>
                    <div className="bg-white w-full max-w-sm rounded-[30px] p-6 shadow-2xl animate-fade-in-up" onClick={e => e.stopPropagation()}>
                        <div className="flex justify-between items-center mb-6">
                            <button onClick={() => onDateChange(subMonths(selectedDate, 1))} className="p-2 hover:bg-gray-100 rounded-full text-gray-400"><FaChevronLeft /></button>
                            <span className="text-xl font-bold text-gray-900">{format(selectedDate, 'yyyy. MM')}</span>
                            <button onClick={() => onDateChange(addMonths(selectedDate, 1))} className="p-2 hover:bg-gray-100 rounded-full text-gray-400"><FaChevronRight /></button>
                        </div>
                        <div className="grid grid-cols-7 text-center mb-4">
                            {dayLabels.map((d, i) => <div key={i} className={`text-xs font-bold ${i === 0 ? 'text-red-400' : 'text-gray-400'}`}>{d}</div>)}
                        </div>
                        <div className="grid grid-cols-7 gap-y-3">
                            {monthDays.map((date, i) => {
                                const isSelected = isSameDay(date, selectedDate);
                                const isCurrentMonth = isSameMonth(date, selectedDate);
                                const isFuture = isAfter(date, today);
                                return (
                                    <div key={i} onClick={() => { if (!isFuture) { onDateChange(date); setIsCalendarOpen(false); } }} className={`relative h-10 flex flex-col items-center justify-center rounded-full transition-all ${!isCurrentMonth ? 'opacity-30' : ''} ${isSelected ? 'bg-[#6C5CE7] text-white shadow-md font-bold' : 'hover:bg-gray-50 text-gray-700'} ${date.getDay() === 0 && !isSelected ? 'text-red-400' : ''} ${isFuture ? 'opacity-20 cursor-not-allowed bg-gray-100 !text-gray-400 hover:bg-gray-100' : 'cursor-pointer'}`}>
                                        <span className="text-sm">{format(date, 'd')}</span>
                                    </div>
                                );
                            })}
                        </div>
                        <button onClick={() => setIsCalendarOpen(false)} className="w-full mt-8 py-3.5 rounded-2xl bg-gray-100 text-gray-600 font-bold hover:bg-gray-200 transition-colors">닫기</button>
                    </div>
                </div>
            )}
        </div>
    );
};

export default MainDashboard;