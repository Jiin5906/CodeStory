import React, { useState } from 'react';
import { FaArrowLeft, FaCamera } from 'react-icons/fa';
import './DiaryEditor.css'; 

const RECOMMENDED_TAGS = [
    { id: 1, name: '일상기록' }, { id: 2, name: '소확행' }, 
    { id: 3, name: '오운완' }, { id: 4, name: '맛집' }
];

const DiaryEditor = ({ selectedDate, onBack, onNext }) => {
    const [content, setContent] = useState('');
    const [tags, setTags] = useState([]);
    const [tagInput, setTagInput] = useState('');
    const [selectedImage, setSelectedImage] = useState(null);
    const [previewUrl, setPreviewUrl] = useState('');
    
    // [추가] 공유 여부 상태
    const [isPublic, setIsPublic] = useState(false);

    const handleTagKeyDown = (e) => {
        if (e.key === 'Enter' && tagInput.trim()) {
            e.preventDefault();
            if (!tags.includes(tagInput.trim())) setTags([...tags, tagInput.trim()]);
            setTagInput('');
        }
    };

    const addRecommendedTag = (tagName) => {
        if (!tags.includes(tagName)) setTags([...tags, tagName]);
    };

    const removeTag = (tagToRemove) => {
        setTags(tags.filter(tag => tag !== tagToRemove));
    };

    const handleImageChange = (e) => {
        const file = e.target.files[0];
        if (file) {
            setSelectedImage(file);
            setPreviewUrl(URL.createObjectURL(file));
        }
    };

    const handleNextClick = () => {
        if (!content.trim()) {
            alert('일기 내용을 입력해주세요.');
            return;
        }
        // [수정] isPublic 상태도 함께 부모(App.jsx)로 전달
        onNext({ content, tags, imageFile: selectedImage, isPublic });
    };

    return (
        <div className="editor-container">
            <div className="editor-header">
                <button onClick={onBack} className="back-btn"><FaArrowLeft /></button>
                <span className="date-title">
                    {selectedDate.toLocaleDateString('ko-KR', { month: 'long', day: 'numeric', weekday: 'long' })}
                </span>
                <button onClick={handleNextClick} className="next-btn">다음</button>
            </div>

            <div className="editor-body">
                {/* 사진 업로드 */}
                <div className="image-upload-section">
                    <input type="file" accept="image/*" id="image-upload" style={{ display: 'none' }} onChange={handleImageChange} />
                    <label htmlFor="image-upload" className="image-upload-label">
                        {previewUrl ? (
                            <img src={previewUrl} alt="preview" className="image-preview" />
                        ) : (
                            <div className="image-placeholder">
                                <FaCamera size={24} color="#888" />
                                <span>오늘의 사진 추가하기</span>
                            </div>
                        )}
                    </label>
                </div>

                {/* [추가] 공유하기 체크박스 (인스타그램 스타일) */}
                <div style={{ margin: '15px 0', padding: '10px', background: '#F8F9FA', borderRadius: '8px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                    <span style={{ fontSize: '14px', fontWeight: 'bold', color: '#495057' }}>🌏 커뮤니티에 공유하기</span>
                    <label className="switch" style={{ position: 'relative', display: 'inline-block', width: '40px', height: '24px' }}>
                        <input 
                            type="checkbox" 
                            checked={isPublic} 
                            onChange={(e) => setIsPublic(e.target.checked)} 
                            style={{ opacity: 0, width: 0, height: 0 }}
                        />
                        <span className="slider round" style={{ 
                            position: 'absolute', cursor: 'pointer', top: 0, left: 0, right: 0, bottom: 0, 
                            backgroundColor: isPublic ? '#6C5CE7' : '#ccc', transition: '.4s', borderRadius: '34px'
                        }}>
                            <span style={{ 
                                position: 'absolute', content: "", height: '16px', width: '16px', 
                                left: isPublic ? '20px' : '4px', bottom: '4px', backgroundColor: 'white', transition: '.4s', borderRadius: '50%' 
                            }}></span>
                        </span>
                    </label>
                </div>

                {/* 태그 및 내용 입력 (기존 코드 유지) */}
                <div className="tag-input-area">
                    <div className="tags-display">
                        {tags.map(tag => <span key={tag} className="tag-chip">#{tag} <span onClick={() => removeTag(tag)} className="tag-remove">×</span></span>)}
                    </div>
                    <input type="text" placeholder="태그 입력 (Enter)" value={tagInput} onChange={(e) => setTagInput(e.target.value)} onKeyDown={handleTagKeyDown} className="tag-input" />
                    
                    <div className="recommend-section" style={{ marginTop: '10px' }}>
                        <p style={{ fontSize: '12px', color: '#888', marginBottom: '8px' }}>🔥 요즘 뜨는 태그</p>
                        <div className="recommend-list" style={{ display: 'flex', flexWrap: 'wrap', gap: '6px' }}>
                            {RECOMMENDED_TAGS.map(tag => (
                                <button key={tag.id} onClick={() => addRecommendedTag(tag.name)} style={{ padding: '4px 10px', borderRadius: '15px', border: '1px solid #E0E0E0', backgroundColor: '#fff', fontSize: '12px', color: '#666', cursor: 'pointer' }}>#{tag.name}</button>
                            ))}
                        </div>
                    </div>
                </div>

                <textarea className="diary-textarea" placeholder="오늘 하루는 어땠나요?" value={content} onChange={(e) => setContent(e.target.value)} />
            </div>
        </div>
    );
};

export default DiaryEditor;