import { useEffect, useState } from 'react';
import { format } from 'date-fns';
import './App.css';

import { authApi, diaryApi } from './services/api';
import Login from './components/auth/Login';
import Sidebar from './components/layout/Sidebar';
import MainDashboard from './components/dashboard/MainDashboard';
import RightPanel from './components/layout/RightPanel';
import DiaryEditor from './components/diary/DiaryEditor';
import EmotionModal from './components/diary/EmotionModal';
import ErrorBanner from './components/common/ErrorBanner';
import CalendarView from './components/calendar/CalendarView';
import MonthlyReport from './components/stats/MonthlyReport';
import Settings from './components/layout/Settings';
import SharedFeed from './components/feed/SharedFeed'; // [추가] 피드 컴포넌트 임포트

function App() {
    const [user, setUser] = useState(null);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState('');

    // 화면 상태
    const [view, setView] = useState('login');

    // 날짜 상태
    const [selectedDate, setSelectedDate] = useState(new Date());
    const [diaries, setDiaries] = useState([]);

    // 일기 임시 저장소 (내용, 태그, 이미지 파일, [추가] 공개여부)
    const [diaryDraft, setDiaryDraft] = useState({ content: '', tags: [], imageFile: null, isPublic: false });
    const [showEmotionModal, setShowEmotionModal] = useState(false);

    useEffect(() => {
        const storedUser = localStorage.getItem('diaryUser');
        if (storedUser) {
            try {
                const parsed = JSON.parse(storedUser);
                setUser(parsed);
                fetchDiaries(parsed.id);
                setView('dashboard');
            } catch (e) {
                console.error("User parsing error", e);
                setView('login');
            }
        } else {
            setView('login');
        }
    }, []);

    const fetchDiaries = async (userId) => {
        if (!userId) return;
        try {
            const data = await diaryApi.getDiaries(userId);
            setDiaries(Array.isArray(data) ? data : []);
        } catch (err) {
            console.error("Failed to fetch diaries", err);
            setDiaries([]);
        }
    };

    const handleLoginSuccess = (userInfo) => {
        setUser(userInfo);
        localStorage.setItem('diaryUser', JSON.stringify(userInfo));
        fetchDiaries(userInfo.id);
        setView('dashboard');
    };

    const handleLogin = async (email, password) => {
        try { const u = await authApi.login(email, password); handleLoginSuccess(u); } catch { alert('로그인 실패'); }
    };
    const handleSignup = async (email, password, nickname) => {
        try { const u = await authApi.signup(email, password, nickname); handleLoginSuccess(u); } catch { alert('가입 실패'); }
    };
    const handleGuestLogin = () => handleLoginSuccess({ id: 0, nickname: '게스트', email: 'guest@temp.com' });

    const handleLogout = () => {
        localStorage.removeItem('diaryUser');
        setUser(null);
        setView('login');
        setDiaries([]);
    };

    const startWriting = (date) => {
        const targetDate = date instanceof Date ? date : new Date();
        setSelectedDate(targetDate);
        setView('editor');
        // 초기화
        setDiaryDraft({ content: '', tags: [], imageFile: null, isPublic: false });
    };

    // DiaryEditor에서 "다음" 버튼 눌렀을 때 호출
    const handleEditorNext = (draftData) => {
        // draftData: { content, tags, imageFile, isPublic }
        setDiaryDraft(draftData);
        setShowEmotionModal(true);
    };

    // [핵심 수정] 최종 저장 (FormData 사용)
    const handleFinalSubmit = async (emotionData) => {
        setLoading(true);
        try {
            if (!user || !user.id) {
                alert("로그인 정보가 만료되었습니다.");
                handleLogout();
                return;
            }

            // ★ 1. FormData 생성 (파일 + 데이터를 한번에 보내기 위함)
            const formData = new FormData();
            
            // 2. 데이터 담기 (Backend DTO 필드명과 일치해야 함)
            formData.append('userId', user.id);
            formData.append('date', format(selectedDate, 'yyyy-MM-dd'));
            formData.append('content', diaryDraft.content);
            formData.append('isPublic', diaryDraft.isPublic); // 공개 여부 전송
            
            // 감정 데이터 담기
            formData.append('mood', emotionData.mood);
            formData.append('tension', emotionData.tension);
            formData.append('fun', emotionData.fun);
            formData.append('emoji', emotionData.emoji);
            formData.append('aiResponse', emotionData.aiResponse || 'AI 응답 없음'); // null 방지
            
            // 태그는 배열이므로 하나씩 담거나 문자열로 변환 필요 (여기선 하나씩)
            if (diaryDraft.tags) {
                diaryDraft.tags.forEach(tag => formData.append('tags', tag));
            }

            // 3. 이미지 파일 담기
            if (diaryDraft.imageFile) {
                formData.append('image', diaryDraft.imageFile);
            }

            // 4. API 호출 (fetch 사용)
            // 주의: headers에 'Content-Type': 'application/json'을 절대 넣으면 안 됩니다!
            // 브라우저가 알아서 boundary 설정을 하도록 둡니다.
            const response = await fetch('http://localhost:8080/api/diary', {
                method: 'POST',
                body: formData
            });

            if (response.ok) {
                await fetchDiaries(user.id); // 목록 갱신
                setShowEmotionModal(false);
                setView('dashboard'); // 홈으로 이동
            } else {
                throw new Error('서버 저장 실패');
            }

        } catch (err) {
            console.error(err);
            setError('일기 저장에 실패했습니다.');
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="app-root">
            {view === 'login' && (
                <div className="animate-fade-in">
                    <Login onLogin={handleLogin} onSignup={handleSignup} onGuestLogin={handleGuestLogin} />
                </div>
            )}

            {view === 'editor' && (
                <div className="animate-fade-in" style={{ position: 'fixed', inset: 0, zIndex: 100, background: '#F0F2F5', display: 'flex', justifyContent: 'center' }}>
                    <div style={{ width: '100%', maxWidth: '600px', background: 'white', boxShadow: '0 0 50px rgba(0,0,0,0.1)' }}>
                        <DiaryEditor selectedDate={selectedDate} onBack={() => setView('dashboard')} onNext={handleEditorNext} />
                    </div>
                </div>
            )}

            {view !== 'login' && view !== 'editor' && (
                <div className="layout-container animate-fade-in">
                    <Sidebar
                        onWriteClick={() => startWriting(selectedDate)}
                        currentView={view}
                        onChangeView={(v) => setView(v)}
                    />

                    <div className="content-area animate-fade-in" key={view} style={{ flex: 1, overflow: 'hidden' }}>
                        {view === 'dashboard' ? (
                            <MainDashboard
                                user={user}
                                diaries={diaries}
                                selectedDate={selectedDate}
                                onDateChange={setSelectedDate}
                                onLogout={handleLogout}
                                onLoginRedirect={() => {
                                    handleLogout();
                                    setView('login');
                                }}
                            />
                        ) : view === 'calendar' ? (
                            <CalendarView user={user} diaries={diaries} />
                        ) : view === 'stats' ? (
                            <MonthlyReport
                                diaries={diaries}
                                currentMonth={selectedDate}
                            />
                        ) : view === 'shared' ? ( // [추가] 감정 공유 화면 연결
                            <SharedFeed />
                        ) : view === 'settings' ? (
                            <Settings
                                user={user}
                                onNicknameChange={(newName) => {
                                    const updatedUser = { ...user, nickname: newName };
                                    setUser(updatedUser);
                                    localStorage.setItem('diaryUser', JSON.stringify(updatedUser));
                                }}
                            />
                        ) : (
                            <div style={{ padding: '50px', textAlign: 'center', color: '#888' }}>준비 중인 기능입니다.</div>
                        )}
                    </div>

                    <RightPanel
                        user={user}
                        selectedDate={selectedDate}
                        onDateSelect={(date) => {
                            setSelectedDate(date);
                            setView('dashboard');
                        }}
                        diaries={diaries}
                        onLogout={handleLogout}
                        onLogin={() => setView('login')}
                    />
                </div>
            )}

            <ErrorBanner message={error} />
            {loading && <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.4)', zIndex: 999, display: 'flex', justifyContent: 'center', alignItems: 'center', color: 'white' }}>저장 중...</div>}
            {showEmotionModal && <EmotionModal onClose={() => setShowEmotionModal(false)} onSave={handleFinalSubmit} />}
        </div>
    );
}

export default App;